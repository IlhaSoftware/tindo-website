<?php
/**
 * Single post partial template.
 *
 * @package rock content
 */

if ( ! defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}
?>

<article <?php post_class('post_single'); ?> id="post-<?php the_ID(); ?>">

    <div class="post_single__header text-center">
        <div class="post-entry__content__category mt-3">
            <?php rock_post_category(); ?>
        </div>
        <h1 class="post_single__title text-uppercase pt-3 pb-2"><?php the_title(); ?></h1>
        <div class="post-entry__content__date pb-4">
            <?php rock_posted_on(); ?>
        </div>
    </div>

    <?php echo get_the_post_thumbnail($post->ID, 'post-single',
        array('class' => 'mb-4')); ?>

    <div class="post_single__content">
        <div class="post_single__content__reading-time">
            <?php echo rock_reading_time(get_the_content()); ?>
        </div>

        <?php the_content(); ?>

    </div><!-- .entry-content -->

</article><!-- #post-## -->
