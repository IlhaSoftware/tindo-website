<div id="highlightsMobile" class="d-block d-md-none carousel slide" data-ride="carousel">
    <ol class="carousel-indicators">
        <?php for (
            $i = 0;
            $i < $template_args['count'];
            $i++
        ) { ?>
            <li data-target="#highlightsMobile" data-slide-to="<?php echo $i; ?>"
                class="<?php echo $i == 0 ? 'active' : null ?>"></li>
        <?php } ?>
    </ol>

    <?php $count = 0; ?>
    <div class="carousel-inner">
        <?php while ($template_args['query']->have_posts()) :
            $template_args['query']->the_post(); ?>

            <div class="carousel-item <?php echo $count == 0 ? 'active' : null ?>">
                <div class="row">

                    <div class="col-md-12">
                        <a href="<?php echo get_the_permalink(); ?>">
                            <?php echo get_the_post_thumbnail($template_args['query']->post->ID,
                                'highlight-square',
                                array('class' => 'w-100')); ?>
                        </a>
                    </div>
                </div>
            </div>
            <?php $count++; ?>
        <?php endwhile; ?>
    </div>
    <a class="carousel-control-prev" href="#highlightsMobile" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#highlightsMobile" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
    </a>
</div>
