<?php
function endTag($count, $total)
{
    if ($count == $total) {
        return null;
    }

    if ($count % 3 == 0) {
        echo '</div></div><div class="carousel-item"><div class="row">';
    }
}

?>
<div id="carouselExampleIndicators" class="carousel slide d-none d-md-block" data-ride="carousel">

    <ol class="carousel-indicators">
        <?php for (
            $i = 0;
            $i < round($template_args['count'] / 3);
            $i++
        ) { ?>
            <li data-target="#carouselExampleIndicators" data-slide-to="<?php echo $i; ?>"
                class="<?php echo $i == 0 ? 'active' : null ?>"></li>
        <?php } ?>
    </ol>

    <?php $count = 1; ?>
    <div class="carousel-inner">
        <div class="carousel-item active">
            <div class="row">
                <?php while ($template_args['query']->have_posts()) :
                    $template_args['query']->the_post(); ?>

                    <div class="col-md-4 pl-0 pr-0 position-relative">
                        <a href="<?php echo get_the_permalink(); ?>">
                            <?php echo get_the_post_thumbnail($template_args['query']->post->ID,
                                'highlight-square',
                                array('class' => 'w-100')); ?>
                        </a>

                        <div class="carousel-title">
                            <a href="<?php echo get_permalink(); ?>"><?php the_title(); ?></a>
                        </div>
                    </div>

                    <?php endTag($count, $template_args['count']); ?>

                    <?php $count++; ?>
                <?php endwhile; ?>
            </div>
        </div>
    </div>
    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
    </a>
</div>
