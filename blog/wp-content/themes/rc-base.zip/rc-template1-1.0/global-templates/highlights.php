<?php

$args = array(
    'post_type'      => 'post',
    'posts_per_page' => 9,
    'order'          => 'DESC',
    'orderby'        => 'date'
);

$the_query = new WP_Query($args); ?>

<div class="pb-5">
    <?php if ($the_query->have_posts()) : ?>

        <?php $post_count = $the_query->post_count; ?>

        <?php hm_get_template_part('global-templates/highlights-desktop', array(
            'query' => $the_query,
            'count' => $post_count
        )) ?>

        <?php wp_reset_postdata(); ?>

        <?php hm_get_template_part('global-templates/highlights-mobile', array(
            'query' => $the_query,
            'count' => $post_count
        )) ?>

    <?php endif; ?>
</div>



