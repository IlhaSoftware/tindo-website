<div class="site-info">
    <?php rock_site_info(); ?>
</div>
