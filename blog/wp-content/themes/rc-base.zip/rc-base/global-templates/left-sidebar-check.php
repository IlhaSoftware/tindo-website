<?php
/**
 * Left sidebar check.
 *
 * @package rock content
 */

if ( ! defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}
?>

<?php
$sidebar_pos = get_theme_mod('rock_sidebar_position');
?>

<div class="col-md content-area" id="primary">
