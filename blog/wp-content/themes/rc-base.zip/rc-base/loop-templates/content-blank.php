<?php
/**
 * Blank content partial template.
 *
 * @package rock content
 */

if ( ! defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

the_content();
