<div class="site-info">
    <div class="pull-left">
        <?php rock_site_info(); ?>
    </div>
    <div class="pull-right">
        <?php get_template_part('global-templates/social', 'networks'); ?>
    </div>
</div>


