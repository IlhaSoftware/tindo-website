<section id="footer" class="site-footer">
    <div class="container">
        <div class="row">
            <?php dynamic_sidebar( 'footerfull' ); ?>
        </div>
    </div>
</section>